
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'business1314151617',
  applicationName: 'my-lambda-app',
  appUid: 'bD97R0FvmPCrTLKPbT',
  orgUid: 'KCL28pvPzHV89xg6CM',
  deploymentUid: '168ebc12-3a16-43e6-aaf1-9f754b08ddc2',
  serviceName: 'my-lambda-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'prd',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.15',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'my-lambda-app-prd-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}